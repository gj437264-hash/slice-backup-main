<?php
/**
 * admin-ajax endpoints used by the admin screen.
 *
 * Every handler checks the capability and a nonce before reading input, except the
 * job tick, which is authorized by the job's random token (so a restore can keep
 * running after the database, and with it the user's session, has been replaced).
 *
 * @package SliceBackup
 */

declare(strict_types=1);

namespace SliceBackup;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AJAX handlers.
 */
final class AjaxController {
    private const ACTIONS = array(
        'slice_backup_job_start'     => 'jobStart',
        'slice_backup_job_status'    => 'jobStatus',
        'slice_backup_job_cancel'    => 'jobCancel',
        'slice_backup_list'          => 'listBundles',
        'slice_backup_inspect'       => 'inspect',
        'slice_backup_delete'        => 'delete',
        'slice_backup_upload_chunk'  => 'uploadChunk',
        'slice_backup_save_settings' => 'saveSettings',
        'slice_backup_estimate'      => 'estimate',
        'slice_backup_report'        => 'lastReport',
        'slice_backup_probe'         => 'probe',
        'slice_backup_download'      => 'download',
        'slice_backup_cloud_test'    => 'cloudTest',
        'slice_backup_cloud_list'    => 'cloudList',
        'slice_backup_cloud_delete'  => 'cloudDelete',
        'slice_backup_schedule_now'  => 'scheduleNow',
        'slice_backup_peer_key'      => 'peerKey',
        'slice_backup_peer_revoke'   => 'peerRevoke',
        'slice_backup_peer_check'    => 'peerCheck',
        'slice_backup_dropbox_start' => 'dropboxStart',
        'slice_backup_dropbox_finish' => 'dropboxFinish',
        'slice_backup_rollback_info'    => 'rollbackInfo',
        'slice_backup_rollback_undo'    => 'rollbackUndo',
        'slice_backup_rollback_discard' => 'rollbackDiscard',
        'slice_backup_log_download'     => 'logDownload',
    );

    public static function init(): void {
        foreach (self::ACTIONS as $action => $method) {
            add_action('wp_ajax_' . $action, array(__CLASS__, $method));
        }
        add_action('wp_ajax_slice_backup_job_tick', array(__CLASS__, 'jobTick'));
        add_action('wp_ajax_nopriv_slice_backup_job_tick', array(__CLASS__, 'jobTick'));
        // A restore replaces the users table and logs the admin out; the job token still allows cancelling.
        add_action('wp_ajax_nopriv_slice_backup_job_cancel', array(__CLASS__, 'jobCancel'));
    }

    private static function guard(): void {
        if (!Plugin::currentUserCan()) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'slice-backup')), 403);
        }
        if (!check_ajax_referer('slice_backup_admin', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Your session has expired. Reload the page and try again.', 'slice-backup'), 'code' => 'bad_nonce'), 403);
        }
    }

    /**
     * Reads a POST field. Call only after guard() (or a token check).
     */
    private static function post(string $key, string $default = ''): string {
        return isset($_POST[$key]) && is_scalar($_POST[$key]) ? (string) wp_unslash($_POST[$key]) : $default; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified in guard() (or job token checked); values sanitized by callers.
    }

    private static function flag(string $key, bool $default = false): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in guard().
        return isset($_POST[$key]) ? MigratorEngine::truthy(self::post($key)) : $default;
    }

    private static function fail(\Throwable $e): void {
        $status = $e instanceof \InvalidArgumentException ? 400 : 500;
        wp_send_json_error(array('message' => Plugin::errorText($e)), $status);
    }

    /**
     * @return array<string, mixed>
     */
    private static function jobPayload(Job $job, bool $withToken): array {
        $data = $job->toArray();
        if ($withToken) {
            $data['token'] = $job->token;
        }
        return $data;
    }

    /* Jobs ---------------------------------------------------------------- */

    public static function jobStart(): void {
        self::guard();

        try {
            $type = sanitize_key(self::post('type'));
            switch ($type) {
                case 'export':
                    $options = array(
                        'export_type'                => sanitize_key(self::post('export_type', 'full')),
                        'multisite_mode'             => self::post('multisite_mode') === 'subsite' ? 'subsite' : 'entire_network',
                        'subsite_id'                 => absint(self::post('subsite_id', '0')),
                        'convert_subsite_standalone' => self::flag('convert_subsite_standalone'),
                        'exclude_spam'               => self::flag('exclude_spam'),
                        'exclude_revisions'          => self::flag('exclude_revisions'),
                        'exclude_transients'         => self::flag('exclude_transients'),
                        'encrypt'                    => self::flag('encrypt'),
                        'passphrase'                 => self::post('passphrase'),
                        'upload'                     => self::flag('upload'),
                        'delete_local'               => self::flag('delete_local'),
                        'push_key'                   => self::flag('push') ? self::post('push_key') : '',
                        'push_restore'               => self::flag('push_restore'),
                    );
                    foreach (MigratorEngine::COMPONENTS as $key) {
                        $options['include_' . $key] = self::flag('include_' . $key);
                    }
                    $job = MigratorEngine::startExport($options);
                    break;

                case 'restore':
                    $options = array(
                        'old_url'            => esc_url_raw(self::post('old_url')),
                        'new_url'            => esc_url_raw(self::post('new_url')),
                        'old_network_domain' => sanitize_text_field(self::post('old_network_domain')),
                        'new_network_domain' => sanitize_text_field(self::post('new_network_domain')),
                        'isolate_conflicts'  => self::flag('isolate_conflicts', true),
                        'passphrase'         => self::post('passphrase'),
                    );
                    foreach (MigratorEngine::COMPONENTS as $key) {
                        $options['restore_' . $key] = self::flag('restore_' . $key);
                    }
                    $job = MigratorEngine::startRestore(sanitize_file_name(self::post('filename')), $options);
                    break;

                case 'upload':
                    $job = MigratorEngine::startUpload(sanitize_file_name(self::post('filename')));
                    break;

                case 'download':
                    $job = MigratorEngine::startDownload(sanitize_file_name(self::post('filename')));
                    break;

                case 'pull':
                    $job = MigratorEngine::startPull(self::post('key'), array('export_type' => sanitize_key(self::post('export_type', 'full'))));
                    break;

                case 'link_import':
                    $job = MigratorEngine::startLinkImport(self::post('url'));
                    break;

                default:
                    throw new \InvalidArgumentException(esc_html__('Unknown job type.', 'slice-backup'));
            }

            MigratorEngine::scheduleBackgroundTick($job);
            wp_send_json_success(self::jobPayload($job, true));
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /**
     * Advances the active job. Authorized by the job token (no nonce, works without a session).
     */
    public static function jobTick(): void {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Authorized by the job's secret token below.
        $id    = isset($_POST['job']) ? sanitize_text_field(wp_unslash((string) $_POST['job'])) : '';
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash((string) $_POST['token'])) : '';
        // phpcs:enable

        $job = Job::load($id);
        if ($job === null || !$job->checkToken($token)) {
            wp_send_json_error(array('message' => __('Unknown or expired job.', 'slice-backup')), 403);
        }

        if ($job->status === 'running') {
            $job = MigratorEngine::tick($job, (float) Plugin::settings()['step_seconds']);
        }
        wp_send_json_success(self::jobPayload($job, false));
    }

    /**
     * The active job (with its token, so a reloaded page can keep driving it), or a finished job by ID.
     */
    public static function jobStatus(): void {
        self::guard();
        $id  = sanitize_text_field(self::post('job'));
        $job = $id !== '' ? Job::load($id) : Job::active();
        wp_send_json_success(array('job' => $job !== null ? self::jobPayload($job, $job->status === 'running') : null));
    }

    public static function jobCancel(): void {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Authorized by the job's secret token below, or by guard().
        $id    = isset($_POST['job']) ? sanitize_text_field(wp_unslash((string) $_POST['job'])) : '';
        $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash((string) $_POST['token'])) : '';
        // phpcs:enable
        if ($id !== '' && $token !== '') {
            $job = Job::load($id);
            if ($job !== null && $job->checkToken($token)) {
                if ($job->status === 'running') {
                    MigratorEngine::cancel($job);
                }
                wp_send_json_success(array('cancelled' => true));
            }
        }

        self::guard();
        $job = Job::active();
        if ($job !== null) {
            MigratorEngine::cancel($job);
        }
        wp_send_json_success(array('cancelled' => $job !== null));
    }

    public static function scheduleNow(): void {
        self::guard();
        try {
            if (!Plugin::settings()['schedule']['enabled']) {
                throw new \InvalidArgumentException(esc_html__('Turn on scheduled backups first.', 'slice-backup'));
            }
            $schedule = Plugin::settings()['schedule'];
            $job      = MigratorEngine::startExport(
                array(
                    'export_type'        => (string) $schedule['preset'],
                    'encrypt'            => !empty($schedule['encrypt']),
                    'upload'             => !empty($schedule['upload']),
                    'delete_local'       => !empty($schedule['upload']) && !empty($schedule['delete_local']),
                    'exclude_spam'       => true,
                    'exclude_transients' => true,
                ),
                'schedule'
            );
            MigratorEngine::scheduleBackgroundTick($job);
            wp_send_json_success(self::jobPayload($job, true));
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /* Bundles -------------------------------------------------------------- */

    public static function listBundles(): void {
        self::guard();

        try {
            $bundles = Storage::listBundles();
            $total   = 0.0;
            foreach ($bundles as $bundle) {
                $total += (float) $bundle['sizeBytes'];
            }
            wp_send_json_success(
                array(
                    'bundles'        => $bundles,
                    'totalSize'      => size_format($total, 1),
                    'currentSiteUrl' => untrailingslashit((string) get_option('siteurl')),
                    'cloudReady'     => Cloud::isConfigured(),
                )
            );
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    public static function inspect(): void {
        global $wpdb;
        self::guard();

        try {
            $name      = sanitize_file_name(self::post('filename'));
            $path      = Storage::path($name);
            $encrypted = Crypto::isEncryptedFile($path);
            $warnings  = array();
            $raw       = null;

            if ($encrypted) {
                $passphrase = self::post('passphrase');
                if ($passphrase === '') {
                    $passphrase = Plugin::storedPassphrase();
                }
                if ($passphrase === '') {
                    wp_send_json_success(array('filename' => $name, 'formattedSize' => size_format(Storage::filesize($path), 1), 'encrypted' => true, 'needsPassphrase' => true, 'manifest' => null, 'warnings' => array()));
                }
                try {
                    $raw = Crypto::readEncryptedManifest($path, $passphrase);
                } catch (\Throwable $e) {
                    wp_send_json_success(array('filename' => $name, 'formattedSize' => size_format(Storage::filesize($path), 1), 'encrypted' => true, 'needsPassphrase' => true, 'passphraseError' => Plugin::errorText($e), 'manifest' => null, 'warnings' => array()));
                }
            } else {
                $raw = Storage::readManifest($path);
            }

            $manifest = Storage::summarizeManifest($raw);

            if ($manifest === null) {
                $warnings[] = __('This file has no bundle.json manifest, so its contents and source site are unknown. It may not be a Slice Backup bundle.', 'slice-backup');
            } else {
                if ($manifest['isMultisite'] && !is_multisite()) {
                    $warnings[] = __('This bundle was made from a multisite network, but this site is a single site. Only the main site will work after restoring.', 'slice-backup');
                }
                if (!$manifest['isMultisite'] && is_multisite()) {
                    $warnings[] = __('This bundle is from a single site, but this is a multisite network. Restoring the database replaces the main site and the network\'s users table.', 'slice-backup');
                }
                if ($manifest['multisiteMode'] === 'subsite' && !$manifest['standalone']) {
                    $warnings[] = __('This bundle holds one network site plus the whole network\'s users table. Restoring it overwrites all network users.', 'slice-backup');
                }
                if ($manifest['tablePrefix'] !== '' && $manifest['tablePrefix'] !== $wpdb->base_prefix) {
                    $warnings[] = sprintf(
                        /* translators: 1: bundle table prefix, 2: this site's prefix. */
                        __('The bundle uses table prefix "%1$s"; it will be converted to this site\'s prefix "%2$s" automatically.', 'slice-backup'),
                        $manifest['tablePrefix'],
                        $wpdb->base_prefix
                    );
                }
                if ($manifest['phpVersion'] !== '' && (int) $manifest['phpVersion'] < 8 && (int) PHP_VERSION >= 8) {
                    $warnings[] = sprintf(
                        /* translators: 1: source PHP version, 2: this server's PHP version. */
                        __('The source site ran PHP %1$s and this server runs PHP %2$s. Old plugins or themes may not work; the compatibility check will deactivate any that would crash the site.', 'slice-backup'),
                        $manifest['phpVersion'],
                        PHP_VERSION
                    );
                }
                if ($manifest['wpVersion'] !== '' && version_compare($manifest['wpVersion'], get_bloginfo('version'), '>') && !in_array('wp_core', $manifest['components'], true)) {
                    $warnings[] = sprintf(
                        /* translators: 1: bundle WordPress version, 2: this site's WordPress version. */
                        __('The bundle is from WordPress %1$s, which is newer than this site (%2$s). Update WordPress first, or the database may not match.', 'slice-backup'),
                        $manifest['wpVersion'],
                        get_bloginfo('version')
                    );
                }
            }

            wp_send_json_success(
                array(
                    'filename'      => $name,
                    'formattedSize' => size_format(Storage::filesize($path), 1),
                    'encrypted'     => $encrypted,
                    'manifest'      => $manifest,
                    'warnings'      => $warnings,
                )
            );
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    public static function delete(): void {
        self::guard();
        try {
            $name = sanitize_file_name(self::post('file'));
            if (!Storage::delete($name)) {
                throw new \RuntimeException(esc_html__('The file could not be deleted. Check the folder permissions.', 'slice-backup'));
            }
            wp_send_json_success(array('deleted' => $name));
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /**
     * Receives one piece of an upload and appends it (see the readme for the protocol).
     */
    public static function uploadChunk(): void {
        self::guard();

        try {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Verified in guard(); tmp_name is a server path.
            $tmp = isset($_FILES['chunk']['tmp_name']) ? (string) $_FILES['chunk']['tmp_name'] : '';
            if ($tmp === '' || !is_uploaded_file($tmp)) {
                throw new \InvalidArgumentException(esc_html__('No upload data was received. The piece may exceed the server upload limit.', 'slice-backup'));
            }

            $result = Storage::receiveChunk(self::post('upload_id'), (float) self::post('offset', '0'), (float) self::post('total_size', '0'), self::post('filename'), $tmp);
            if (isset($result['expected'])) {
                wp_send_json_error(array('code' => 'offset_mismatch', 'expected' => $result['expected'], 'message' => __('Upload out of sync; resuming.', 'slice-backup')), 409);
            }
            wp_send_json_success($result);
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /* Settings ------------------------------------------------------------- */

    public static function saveSettings(): void {
        self::guard();

        try {
            $section = sanitize_key(self::post('section', 'general'));
            $input   = array();
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in guard().
            foreach (array_keys($_POST) as $key) {
                $input[(string) $key] = self::post((string) $key);
            }
            Plugin::saveSettings($input, $section);
            wp_send_json_success(
                array(
                    'settings'   => Plugin::publicSettings(),
                    'nextRun'    => Scheduler::nextRun(),
                    'cloudReady' => Cloud::isConfigured(),
                    'message'    => __('Settings saved.', 'slice-backup'),
                )
            );
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    public static function cloudTest(): void {
        self::guard();

        try {
            $saved  = Cloud::config();
            // Secret fields left empty mean "keep the saved value".
            $secret = static function (string $field) use ($saved): string {
                $value = self::post($field);
                return $value !== '' ? $value : (string) ($saved[$field] ?? '');
            };
            $host   = trim(sanitize_text_field(self::post('sftp_host')));
            $port   = max(1, min(65535, absint(self::post('sftp_port', '22'))));
            $config = array(
                'provider'         => sanitize_key(self::post('provider')),
                'access_key'       => sanitize_text_field(self::post('access_key')),
                'secret_key'       => $secret('secret_key'),
                'bucket'           => sanitize_text_field(self::post('bucket')),
                'region'           => sanitize_text_field(self::post('region')),
                'endpoint'         => esc_url_raw(self::post('endpoint')),
                'account_id'       => sanitize_text_field(self::post('account_id')),
                'path_style'       => self::flag('path_style', true),
                'path'             => sanitize_text_field(self::post('path')),
                'sftp_host'        => $host,
                'sftp_port'        => $port,
                'sftp_user'        => sanitize_text_field(self::post('sftp_user')),
                'sftp_auth'        => self::post('sftp_auth') === 'key' ? 'key' : 'password',
                'sftp_password'    => $secret('sftp_password'),
                'sftp_key'         => $secret('sftp_key'),
                'sftp_key_pass'    => $secret('sftp_key_pass'),
                // A changed host must be verified from scratch.
                'sftp_fingerprint' => ($host === $saved['sftp_host'] && $port === (int) $saved['sftp_port'] && !self::flag('sftp_forget_key')) ? (string) $saved['sftp_fingerprint'] : '',
                'dropbox_app_key'  => sanitize_text_field(self::post('dropbox_app_key')),
                'dropbox_refresh'  => (string) $saved['dropbox_refresh'],
                'dropbox_account'  => (string) $saved['dropbox_account'],
            );
            wp_send_json_success(Cloud::test($config));
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    public static function cloudList(): void {
        self::guard();
        try {
            if (!Cloud::isConfigured()) {
                wp_send_json_success(array('configured' => false, 'items' => array()));
            }
            $items = array();
            foreach (Cloud::listBundles() as $object) {
                $items[] = array(
                    'filename'      => $object['filename'],
                    'sizeBytes'     => $object['size'],
                    'formattedSize' => size_format($object['size'], 1),
                    'modified'      => $object['modified'],
                    'modifiedDate'  => wp_date((string) get_option('date_format') . ' ' . (string) get_option('time_format'), $object['modified']),
                );
            }
            wp_send_json_success(
                array(
                    'configured' => true,
                    'items'      => $items,
                    'label'      => Cloud::describe(),
                )
            );
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    public static function cloudDelete(): void {
        self::guard();
        try {
            Cloud::delete(sanitize_file_name(self::post('file')));
            wp_send_json_success(array('deleted' => true));
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /* Site-to-site transfer ------------------------------------------------ */

    public static function peerKey(): void {
        self::guard();
        $key = Peer::generateKey(absint(self::post('hours', '24')));
        wp_send_json_success(array('key' => $key, 'expires' => (int) Plugin::settings()['peer']['expires']));
    }

    public static function peerRevoke(): void {
        self::guard();
        Peer::revoke();
        wp_send_json_success(array('revoked' => true));
    }

    public static function peerCheck(): void {
        self::guard();
        try {
            $info = Peer::ping(Peer::parseKey(self::post('key')));
            wp_send_json_success(
                array(
                    'site'    => (string) ($info['site'] ?? ''),
                    'name'    => (string) ($info['name'] ?? ''),
                    'version' => (string) ($info['version'] ?? ''),
                    'wp'      => (string) ($info['wp'] ?? ''),
                    'php'     => (string) ($info['php'] ?? ''),
                    'busy'    => !empty($info['busy']),
                )
            );
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /* Dropbox -------------------------------------------------------------- */

    /**
     * Starts the Dropbox connection: remembers a PKCE verifier and returns the approval URL.
     */
    public static function dropboxStart(): void {
        self::guard();
        $appKey = sanitize_text_field(self::post('app_key'));
        if ($appKey === '') {
            wp_send_json_error(array('message' => __('Enter your Dropbox app key first.', 'slice-backup')), 400);
        }
        $verifier = DropboxDestination::newVerifier();
        set_transient('slice_backup_dropbox_pkce_' . get_current_user_id(), Crypto::seal($verifier . '|' . $appKey), 30 * MINUTE_IN_SECONDS);
        wp_send_json_success(array('url' => DropboxDestination::authorizeUrl($appKey, $verifier)));
    }

    /**
     * Finishes the Dropbox connection with the code the user pasted.
     */
    public static function dropboxFinish(): void {
        self::guard();
        try {
            $stored = Crypto::open((string) get_transient('slice_backup_dropbox_pkce_' . get_current_user_id()));
            if ($stored === '' || strpos($stored, '|') === false) {
                throw new \InvalidArgumentException(esc_html__('The connection request expired. Click "Connect Dropbox" again.', 'slice-backup'));
            }
            list($verifier, $appKey) = explode('|', $stored, 2);
            $result = DropboxDestination::exchangeCode($appKey, sanitize_text_field(self::post('code')), $verifier);
            delete_transient('slice_backup_dropbox_pkce_' . get_current_user_id());

            $s                             = Plugin::settings();
            $s['cloud']['provider']        = 'dropbox';
            $s['cloud']['dropbox_app_key'] = $appKey;
            Plugin::replaceSettings($s);
            Plugin::saveDropboxConnection($result['refresh'], $result['account']);

            wp_send_json_success(
                array(
                    'account' => $result['account'],
                    /* translators: %s: Dropbox account name. */
                    'message' => sprintf(__('Dropbox connected: %s', 'slice-backup'), $result['account'] !== '' ? $result['account'] : __('account linked', 'slice-backup')),
                )
            );
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /* Misc ----------------------------------------------------------------- */

    public static function estimate(): void {
        self::guard();
        wp_send_json_success(array('sizes' => SystemCheck::estimateSizes()));
    }

    public static function lastReport(): void {
        self::guard();
        $report = get_site_option(Plugin::OPTION_REPORT);
        if (is_array($report)) {
            // Rebuilt for this request: the stored nonce may have been created by an
            // unauthenticated background request when the restore finished, and would not
            // verify for whoever is viewing the report now.
            $report['logUrl'] = RestoreLog::downloadUrl((string) ($report['logFile'] ?? ''));
        }
        wp_send_json_success(array('report' => is_array($report) ? $report : null));
    }

    /**
     * Whether a safety copy from the last restore is available, and what it covers.
     */
    public static function rollbackInfo(): void {
        self::guard();
        wp_send_json_success(array('rollback' => RestoreRollback::info()));
    }

    /**
     * Puts the site back as it was before the last restore.
     */
    public static function rollbackUndo(): void {
        self::guard();
        try {
            $result = RestoreRollback::undo();
            wp_send_json_success(array(
                'message' => sprintf(
                    /* translators: 1: number of tables, 2: number of folders. */
                    __('Restore undone: %1$d database tables and %2$d plugin/theme folders were put back.', 'slice-backup'),
                    $result['tables'],
                    $result['folders']
                ),
            ));
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /**
     * Deletes the safety copy of the last restore to free up space.
     */
    public static function rollbackDiscard(): void {
        self::guard();
        try {
            $result = RestoreRollback::discard();
            wp_send_json_success(array(
                'message' => sprintf(
                    /* translators: 1: number of tables, 2: number of folders. */
                    __('Safety copy deleted: %1$d database tables and %2$d plugin/theme folders were removed.', 'slice-backup'),
                    $result['tables'],
                    $result['folders']
                ),
            ));
        } catch (\Throwable $e) {
            self::fail($e);
        }
    }

    /**
     * Streams a saved restore/backup log. Uses its own nonce because the link is opened
     * directly by the browser.
     */
    public static function logDownload(): void {
        if (!Plugin::currentUserCan()) {
            wp_die(esc_html__('You do not have permission to download reports.', 'slice-backup'), '', array('response' => 403));
        }
        $nonce = isset($_GET['nonce']) ? sanitize_text_field(wp_unslash($_GET['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'slice_backup_log_download')) {
            wp_die(esc_html__('This download link has expired. Reload the page and try again.', 'slice-backup'), '', array('response' => 403));
        }
        $name = isset($_GET['file']) && is_scalar($_GET['file']) ? sanitize_file_name(wp_unslash((string) $_GET['file'])) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        try {
            $path = RestoreLog::path($name);
        } catch (\Throwable $e) {
            wp_die(esc_html(Plugin::errorText($e)), '', array('response' => 404));
        }
        Storage::streamFile($path, 'text/plain; charset=utf-8');
    }

    public static function probe(): void {
        self::guard();
        wp_send_json_success(array('row' => SystemCheck::webAccessProbe(self::flag('force'))));
    }

    /**
     * Streams a bundle. Uses its own nonce because the link is opened by the browser.
     */
    public static function download(): void {
        if (!Plugin::currentUserCan()) {
            wp_die(esc_html__('You do not have permission to download bundles.', 'slice-backup'), '', array('response' => 403));
        }
        $nonce = isset($_GET['nonce']) ? sanitize_text_field(wp_unslash($_GET['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'slice_backup_download')) {
            wp_die(esc_html__('This download link has expired. Reload the Backups page and try again.', 'slice-backup'), '', array('response' => 403));
        }

        $name = isset($_GET['file']) && is_scalar($_GET['file']) ? sanitize_file_name(wp_unslash((string) $_GET['file'])) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        try {
            $path = Storage::path($name);
        } catch (\Throwable $e) {
            wp_die(esc_html(Plugin::errorText($e)), '', array('response' => 404));
        }

        Storage::streamFile($path);
    }
}
